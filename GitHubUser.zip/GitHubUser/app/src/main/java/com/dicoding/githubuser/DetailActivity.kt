package com.dicoding.githubuser

import android.os.Bundle
import android.support.annotation.StringRes
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.githubuser.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayoutMediator
import com.squareup.picasso.Picasso

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setTitle("Detail Github User")

        val detailViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailViewModel::class.java)
        detailViewModel.dataUser.observe(this) { dataUser -> setUserData(dataUser) }
        detailViewModel.isLoading.observe(this) { showLoading(it) }

        val dataUsers = intent.getParcelableExtra<User>("key_user")!!
        detailViewModel.searchUser(dataUsers.nama)

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        binding.viewPager.adapter = sectionsPagerAdapter
        TabLayoutMediator(binding.tabs, binding.viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

        sectionsPagerAdapter.username = dataUsers.nama
    }

    private fun setUserData(userData: DetailUserResponse) {
        binding.tvName.text = userData.name
        binding.tvUsername.text = userData.login
        binding.tvFollowers.text = getString(R.string.followers, userData.followers)
        binding.tvFollowing.text = getString(R.string.following, userData.following)
        Picasso.get().load(userData.avatarUrl).into(binding.ivProfilePicture)
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}
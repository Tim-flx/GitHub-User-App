package com.dicoding.githubuser

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser.databinding.FragmentFollowBinding

class FollowFragment : Fragment() {

    private lateinit var binding: FragmentFollowBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFollowBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var position: Int? = null
        var username: String? = null

        val followViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowViewModel::class.java)
        followViewModel.listFollow.observe(viewLifecycleOwner) { listFollow -> setUserData(listFollow) }
        followViewModel.isLoading.observe(viewLifecycleOwner) { showLoading(it) }

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.rvProfile.layoutManager = layoutManager
        val emptyAdapter = EmptyAdapter()
        binding.rvProfile.adapter = emptyAdapter
        val itemDecoration = DividerItemDecoration(requireActivity(), layoutManager.orientation)
        binding.rvProfile.addItemDecoration(itemDecoration)

        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }
        Log.d("FollowFragment", "position = $position, username = $username")
        if (position == 1){
            followViewModel.searchFollower(username!!)
        } else {
            followViewModel.searchFollowing(username!!)
        }
    }

    private fun setUserData(followData: List<ItemsItem?>?) {
        val listFollow = ArrayList<User>()
        if (followData != null) {
            for (ItemsItem in followData) {
                val filteredData = User(nama = ItemsItem?.login!!, foto = ItemsItem.avatarUrl!!)
                listFollow.add(filteredData)
            }
        }

        val adapter = ListFollowAdapter(listFollow)
        binding.rvProfile.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object {
        const val ARG_POSITION = "section_number"
        const val ARG_USERNAME = "username"
    }
}
